                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2630459
Train Horn - Metric 20mm by GrouseGrouse is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

This is a remake of Gatewood's pretty cool train horn. It is designed to work with 20mm OD conduit, which is cheaply available almost anywhere; unlike 1-inch piping. The spur is also now vertical, and a little thicker. Find his design here: https://www.thingiverse.com/thing:979623


PARTS
6 M3 bolts and nuts (14mm or longer)
Flexible hose (9-11mm ID, depending on stretchiness)
Something to use as a diaphragm (tougher than a balloon, but no tougher than an inner tube)
20mm OD conduit
A source of compressed air or CO2 (I use a modified paintball bottle).

PROBLEMS AND TROUBLESHOOTING:
Performance varies between diaphragms and pressures. If you can't make a fairly loud sound by blowing into it, chances are your diaphragm is too thick.
The pipe needs to be TOUCHING the diaphragm, but not pressed so hard up against it that it can't vibrate.

This design can be used by anyone who wants it. Have fun :) If you want the Fusion 360 files, I can provide :)

HOW TO PRINT:
If you print these parts with the biggest circle down, you can print the whole thing without any supports.

Make sure you have lots of perimeters. I'd suggest at least four.

The spur which connects to the vinyl tubing is meant to be vertical. This means you need to have your layer adhesion nailed down! If you're getting bad results with PLA, consider swapping to PETG. You could also try printing on an angle with lots of support.

Note that the 20mm conduit is meant to fit in REALLY tightly, so if you're overextruding slightly, it might be impossible! But you don't want to risk under-extruding the spur! If you can't get the conduit in, try scaling it up slightly. 

Print the tip first, then you can check if you need to scale without wasting too much filament.