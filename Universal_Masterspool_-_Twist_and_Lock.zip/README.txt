                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:2823667
Universal Masterspool - Twist and Lock by 3d-workshop is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

This MasterSpool Design is inspired by the idea from Richard Horne to avoid waste and reduce shipping weight.
My intention was to reduce the amount of filament and printing time, needed to build this spool by changing the locking mechanism from a threat to sort of a bayonet catch. I ended up with this lightweight but rigid "Masterspool - Twist and Lock". 
__________________________________________________________________________

To build the Masterspool Twist and Lock you will need three different parts:
- the hub
- the side part (you need two of them)
- and the opening tool. One tool should serve for all your spools ([l-type part1](https://www.thingiverse.com/download:5436989) and [l-type part2](https://www.thingiverse.com/download:5436992) or [s-type](https://www.thingiverse.com/download:5436713))

Depending on the manufacturer you will need a different spool size. Choose the parts you need from the tables below.
In order to cover the large bandwidth of different coils, I had to develop 2 types. Type-s is for the coils with small inner diameter, Type-l for those with large inner diameter. All parts of the same type are compatible with each other.

For assembly and disassembly instructions take a look at the video below or follow this link: https://youtu.be/xfV2luRR-po

To attach labeling stickers use the ["ClipOn"](https://www.thingiverse.com/download:5437005) (only works with side parts labeled l-side-197-xx)

# Choose the parts you need

how to read hub labelling:     t - hub -  i - w
------------------------------------------

![Alt text](https://cdn.thingiverse.com/assets/47/ee/d8/16/a9/MeasurementCoil.jpg)

- t (Type) all parts of the same type are interchangeable with each other (right now there are 2 different types: s (small) and l (large)
- w (width) of the refill coil
- i (inner diameter)
- o (outer diameter)


Here is a table showing all the available sizes of hubs.

| hub   |print with supports     |brands   |  
|---------------------| --------------------------------------|--------------|
|......................... |....................................... |...................
|[s-hub-076-76](https://thingiverse.com/thing:3139890/) |- not needed |unkown
|......................... |....................................... |...................
|[l-hub-130-27](https://thingiverse.com/thing:3141264) |- yes | - sample spools
|[l-hub-102-46](https://thingiverse.com/thing:3141262) |- not needed |- Masterspool standard width
| | |- 3d-printworks elefilament (750gr)
|[l-hub-102-45](https://thingiverse.com/thing:3140646) |- not needed |- dasfilament.de (850gr refill)
|[l-hub-102-27](https://thingiverse.com/thing:3140638) |- not needed |- sample spools
|[l-hub-100-62](https://thingiverse.com/thing:3140616) |- not needed |- Filastruder - veracity refill (750gr and 1kg)
|[l-hub-098-57](https://www.thingiverse.com/thing:3140607) |- not needed |- KVP Filament Koil (750gr and 1kg)
| | |- other SlantSpool compatible coils

Feel free to transmit further specs of other filament refills to complete this table!

Hub print settings:

- 2 Wall Lines
- 3 Bottom Layers
- 4 Top Layers
- 0% infill
- optimized for 0.4 Nozzle
- supports only needed, when mentioned in the table above

__________________________________________________________________________



how to read side part labelling:     t - side -  o  -  i
------------------------------------------

![Alt text](https://cdn.thingiverse.com/assets/1f/7c/7e/27/19/mesurement_sidpart.jpg)

- t (Type) all parts of the same type are interchangeable with each other (right now there are 2 different types: s (small) and l (large)
- i (inner diameter)
- o (max. outer diameter)

This table shows all available side parts.

| sidepart   |special features     |
|---------------------| --------------------------------------|
|......................... |....................................................................................................... |
|[s-side-180-50](https://www.thingiverse.com/download:5516945/) | so far, the only s-type side part, only compatible with "s" hubs
|......................... |....................................................................................................... |
|[l-side-197-70](https://www.thingiverse.com/download:5437007/) |  big center hole 70mm
|[l-side-197-70RS](https://www.thingiverse.com/download:5437192) | providing a wider running surface  for Spoolholders with bearings
|[l-side-197-52](https://www.thingiverse.com/download:5437009) | standard center hole of 52mm
|[l-side-170-70](https://www.thingiverse.com/download:5437010) | smaller outer diameter for smaller printbeds
|[l-side-170-52](https://www.thingiverse.com/download:5437008) | smaller outer diameter, standard inner diameter

Print settings for side parts and the opening tools
print settings:

- 4 wall lines (side parts), 2 wall lines (opening tool)
- 3 Bottom Layers
- 4 Top Layers
- 20% infill
- optimized for 0.4 Nozzle
- supports nod needed

<iframe src="//www.youtube.com/embed/xfV2luRR-po" frameborder="0" allowfullscreen></iframe>

<iframe src="//www.youtube.com/embed/oJt3FxKPDTk" frameborder="0" allowfullscreen></iframe>

<iframe src="//www.youtube.com/embed/n6Kyn9_FQL8" frameborder="0" allowfullscreen></iframe>
The l-type opening tool consists of two parts. The center ring allows an easy way to attach the tool. It works with both side part wether you have choosen the 52mm or the 70mm mounting hole. Simply turn the center part of the opening tool upside down to match the mounting hole diameter.