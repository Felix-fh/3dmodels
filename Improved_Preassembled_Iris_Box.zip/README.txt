                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2567044
Improved Preassembled Iris Box by qanalog is licensed under the Creative Commons - Attribution - Share Alike license.
http://creativecommons.org/licenses/by-sa/3.0/

# Summary

This is a modification of Emmett's excellent Preassembled Iris Box.  I've made the following changes:

* Extend the internal tabs to prevent the outer shell from lifting up when the box is closed.  This lets you pick up the box when closed without worrying that the leaves will fall out of the top pegs.
* Add support at the interface between the base and the outer shell.  This makes printing easier as the outer shell isn't printed on air anymore, but this has to be cut in post processing (see photos)
* Remove the sharp base and replace it with a much more rounded one that's easier on the hands.
* Increase the thickness of the bottom of the box to make it sturdier.

The HQ STL file was generated with the sphere resolution set to 160, the other STL is at 120.

# Print Settings

Printer Brand: Ultimaker
Printer: Ultimaker 2
Rafts: No
Supports: No
Resolution: 0.1
Infill: 50%

# Post-Printing

Carefully cut out the supports with a hobby knife, then sand the interior smooth so that the outer shell can turn freely.

Be careful with trying to force the leaves open the first time, my test print had one leaf stuck and I ended up breaking one of the internal pieces trying to get it to close.  To unstick my leaf, I inserted a painting trowel between the leaves and the inner/outer shell.  Then once I got the leaves to close a bit, pulling on them from the top helped.  Another technique I tried was pushing on the leaves from the bottom, or using a screw driver pushing on them sideways through the narrow slit.

Opening and closing the box multiple times smooths it out a bit.  You could then apply grease to improve the motion if desired.