                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1897372
Mr. Toothy Lost Tooth Delivery & Reward Device by geeksmithing is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

This container is a fun way to help deliver child's lost teeth to the Tooth Fairy and holds rewards quite nicely.

Please follow Geeksmithing on [YouTube](https://www.youtube.com/user/troymcklure2002), [Twitter](http://twitter.com/geeksmithing), [Instagram](http://instagram.com/geeksmithing), or [Facebook](http://facebook.com/geeksmithing) to keep up to date on my creations!

# Print Settings

Rafts: Doesn't Matter
Supports: Yes
Resolution: .2

Notes: 
I used clear PETG for my print, but should work with your favorite filament just fine!  This can be scaled accordingly to hold just coins or even folded dollars.

It might be in your best interest to print two to facilitate the swapping of Tooth Fairy related paraphernalia, :)

I recommend minimal supports for the under lip of the lid. Easy peasy.