                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2575494
Jumping Beetle by LoboCNC is licensed under the Creative Commons - Attribution - Share Alike license.
http://creativecommons.org/licenses/by-sa/3.0/

# Summary

Just tap this little bug on the snout and he goes flying!  His "abdomen" is a coiled leaf spring that you flex and latch onto his "thorax".  Tap on his "head" to release the spring and *Boing!* he goes.

Watch: https://youtu.be/0bCjufvA-p0



# Print Settings

Printer: UDIO
Rafts: No
Supports: No
Resolution: 0.2mm
Infill: 15%

Notes: 
Print one of each part.  For the body, make sure your line width is set to 0.5mm as this will make the spring print solid with exactly 2 perimeters.

I recommend using PLA.  PETG or ABS won't give you a very stiff spring.

# Post-Printing

Note that in each set of legs, there is one leg that extends slightly further forward.  When assembling the legs into the body, this extended leg should be oriented  towards the "head" of the beetle.