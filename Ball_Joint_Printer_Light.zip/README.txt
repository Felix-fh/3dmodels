                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1394567
Ball Joint Printer Light by jmc5113 is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

High Powered light for printer or other 8020 extrusion project. 

Clean design allows the wires to pass through the ball joints, but still offers lots of flexibility.

Use  1W to 3W LED:
http://www.ebay.com/itm/1W-3W-High-Power-cool-warm-white-3000k-4000k-10000k-20000k-LED-20mm-star-pcb-/141801976567?var=&hash=item21040e72f7:m:mtnGxNiwP4t_jmTWW970UGw

A switching voltage regulator is also required to power the LED at the required 3.2V from your printers 12-24V power supply.

http://www.ebay.com/itm/5pcs-Re-DC-DC-3A-Buck-Converter-Adjustable-Step-Down-Power-Supply-Module-LM2596S-/221991448900?hash=item33afb8b144:g:d5YAAOSwX~dWktJo