                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:2185309
Binocular Camera Mount by SteelCityElectronics is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

Just an experiment to see if I can photograph closeup photos of the moon through my binoculars. The binoculars are Celestron Skymaster.

My Olympus TG-4 has a removable front ring which accessories can be attached to. After a lot of prototyping I successfully managed to get the dimensions correct.

The camera front ring attaches to the binocular eyepiece mount using magnets. Magnets are 7mm diameter and 3mm thick.

Initial test results are not as sharp as I was expecting. However, this blur may be due to the camera's internal image stabilisation causing problems. Due to poor weather recently, I haven't had a chance to try again with image stabilisation turned off.

Just putting this project up on Thingiverse as someone might want to use the ring mount for another project. 

Project [files are available](https://cad.onshape.com/documents/82133d25bfa9fe4622fd1e7e/w/5939c289e229530d0e317724/e/4ca2e2f2d4c9d2530f34b5ee) at Onshape.

Object was printed in PETG with only 1 perimeter.

The binocular eyepiece color uses an M3 screw and nut to clamp around the eyepiece. I used my [M3 nut knob](http://www.thingiverse.com/thing:2153764) design for the thumbscrew.

# Print Settings

Printer: Da Vinci 1.0
Rafts: No
Supports: No
Resolution: 0.2mm
Infill: 20%