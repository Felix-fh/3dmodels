                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2674461
Customizable Origami Pac-Man by mightynozzle is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

This is a customizable 2D origami / geometric art of Pac-Man. You can glue it into square picture frame (e.g. Ikea Ribba), use it as pendant, rings, earrings or just place it on a shelf...
Link to the corresponding ghost: [Customizable Pac-Man Ghost](https://www.thingiverse.com/thing:2659699)

####Customizable Settings
Use the Customizer or OpenSCAD to create your own.

You can set following paramters:
- the max size of the longest side and the height
- thickness of the outer and inner outline

#####Customizable Origami Series

This is part of my [Customizable Origami](https://www.thingiverse.com/mightynozzle/collections/origami) series. Follow me, if you want to be informed about a new part of this series!

####How to support me?
Do you like my things and do you want to support me? You can use these links if you want to buy something. This helps me doing more things. Thanks!

Banggood: https://goo.gl/ZXgx3A
Gearbest: https://goo.gl/FfE59f
Aliexpress: https://goo.gl/bQLi15

# Print Settings

Printer: Anet AM8
Rafts: No
Supports: No
Resolution: 0.2
Infill: 50%