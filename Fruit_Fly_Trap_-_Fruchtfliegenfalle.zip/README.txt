                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:962737
Fruit Fly Trap - Fruchtfliegenfalle by Meister is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

A lid for common baby jars in order to kill fruit flies. The jar should have a diameter of 50 mm with a height of about 9 mm. I used jars from HIPP. Fill the jar with about one finger height of vinegar and water (mix 1:1) and a droplet of dish soap (so the flies are drowning).  

Eine Deckel für übliche Babygläschen, um Fruchtfliegen zu fangen. Das Gläschen wird dann mit 1 cm Essig/Wasser 1:1 Mischung und einem Tropfen Spülmittel gefüllt. Dann diesen Deckel drauf und dort hingestellt, wo die Fliegen sich aufhalten.  

Fly picture curtsey of https://de.wikipedia.org/wiki/Datei:Drosophila_melanogaster_-_side_(aka).jpg