                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2833025
Anet 8 Z endstop - Final de carrera Z by PaulDrones is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

Esta es una solución al endstop de la Anet 8  (la cual es dificil de acceder y ajustar), y con estas piezas accedemos sin dificultad, y con un solo tornillo (en vez de 4) ajustamos el espacio del extrusor con la base (cama).

# Post-Printing

![Alt text](https://cdn.thingiverse.com/assets/7f/b2/e6/d0/3d/Z_ajuste.PNG)

## Ajustador de altura

En esta pieza tenemos un par de opciones para el tornillo de ajuste:
 
1) Podemos hacer rosca de métrico 3 con lo cual podremos atornillar y desatornillar el tonillo de M3 x 30mm para el ajuste, bloqueándolo con una tuerca M3

2) Podemos taladrar con broca de M3 a través y colocar una tuerca en cada extremo para fijar la altura del tornillo M3 x 30mm.