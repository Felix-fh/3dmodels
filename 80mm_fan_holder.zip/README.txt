                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:2190277
80mm fan holder by ztxdk is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

NOTE: Skull/Punisher fan guard NOT included, link below!

Just a simple 80mm fan holder that allows the fan to be adjusted.
Print two of each parts and assemble..
You'll need two m3 bolts, two m3 nuts and some washers...

I use it with a usb to 9v boost converter and a small usb batterypack.
This is the [boost converter](http://www.banggood.com/USB-DC-5V-to-DC-9V-Step-up-Module-Converter-Male-Connector-Plue-2_1x5_5mm-p-1052130.html?p=VN01125680674201608E).

Fan guard is not included, it's not my design.
It's thing number: [757895](http://www.thingiverse.com/thing:757895)
But If you are like me, do print some guards and save your fingers...



# Print Settings

Rafts: No
Supports: No
Resolution: 0,2
Infill: 15%