                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1871940
The Triplex - Fidget Spinner by hodginsa is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

**Just Launched the Five Dollar Fidget Spinner Kickstarter! Check it out here! https://www.kickstarter.com/projects/idlehandsdev/five-dollar-fidget-spinner**  

This takes standard skateboard bearings, 22mm OD, 8mm ID, 7mm Wide

Please consider supporting me on Patreon so I can continue to release my projects for free!
https://www.patreon.com/seanhodgins

Or support me by buying a fidget from my shapeways store!
https://www.shapeways.com/shops/idlehands?section=Fidget+Spinners&s=0

Subscribe to my YouTube for more cool projects!
http://youtube.com/seanhodginsfilms

https://www.youtube.com/watch?v=iP-wCNDS2kg

**Fidgets shown in image are printed in SLS nylon from Shapeways. The STL on thingiverse has the fillet removed and is slightly different for improved home printing.