                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:2282763
Adjustable Earplug by aajohan is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

This is a neat little earplug with adjustable damping that I designed. It's meant for concertgoers and musicians, and provides a relatively linear (bass to treble) dB reduction ranging from almost no damping to medium damping (that's at least how I would describe it).
Just use a standard, comfortable silicone or foam ear tip of your liking.
Adjust the sound reduction by turning the knob - I've made it relatively loose so you should be able to adjust it while it's in your ear, but that will depend on your printer as well.
I also made a small box that fits two earplugs.

Enjoy, and take good care of your ears!

# Print Settings

Printer: Monoprice Select Mini
Rafts: No
Supports: No
Resolution: 0.175
Infill: 100%

Notes: 
Print the two parts upright as they're designed. If your printer is prone to elefant's foot (your prints bulge out at the bottom) you may want to print Part1 upside down to ensure sufficient room for the threads.
If you print the box as well, there's no reason to make that solid.