# Fairphone-2-case-3D-files
This are files to create and build your own covers for the Fairphone 2 with a 3D printer.

These files are to be used at your own risk!