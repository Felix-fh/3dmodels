                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:3235601
Marble Run Track Extension Parts - Compatible to Gravitrax (R) by Mike0365 is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

I really like the Gravitrax (R) from Ravensburger a lot. I think it is currently the best marble track on the market. However, I there are a couple of things I wanted to improve:

1) In order to build a higher tower, you need to stack many of these gray 10 mm high hexagons. My design allows to stack the parts, using round 6mm plastic rods. You only have to buy some cheap rods and cut them to different lengths, in order to build towers.
See third picture.

2) In the original design you cannot run a marble through a tower, because they are built as a stack of "massive" hexagons. In my design, the 6mm rods only go HALF way through the parts. You can stack a "hexagon" on top of rods and then add just more rods and more hexagons. The ball can roll through the tower.

3) The original parts have a VERY loose fit, when you stack them. My design has a bit more a gun fit. Parts do not fall apart as easy as the original parts.


This is Version 2. In Version 1 all the parts really were hexagons and most of them needed support material for printing. In Version 2, I removed most unnecessary material. I do not want these extensions to look like the original parts in any way because they are just not original parts and they are no copies.  I also changed the clip and clip mounting in a way, that does not require support material anymore. With the clips assembled, the parts of course fit the original hexagons, just a bit more tight. The clips are meant to be fixed in the bottom of the different parts using glue. I typically use Cyan Acrylate (high speed) glue. That does a great job with PLA. Second picture shows, how the clip goes into the bottom of the parts.

The orange part in the overview picture ist just a wider variant of the blue part. It stands more stable. It is meant to be used with a clip and put on the base plate or any other hex adapter in the system. 

I am not trying to cannibalize the original. It is a really great system. Therefore I am not trying to copy or replace original parts.  I am only adding parts, that make it even a greater system and that are not available from Ravensburger.

Besides the STL files and the G-Code for Prusa i3 MK3 there is also the 3D CAD file in native TurboCad format. If anybody needs to have STP, just let me know.

If anybody from Ravensburger reads this:  
Please feel free to pick up my ideas and use my designs. It would be great to make these things commercially available to the huge majority of your customers who do not have 3D printers and just want to buy the parts from you. 
Thank you for creating Gravitrax !

-----------

UPDATE  2018/11/25:
Replaced Part Number 6  because it did not always print out really well. 
Changed the central material saving core to have a bit more material around the tracks.
Updated g-code files, STL file and TCP file.

For those who do not want to mess around with round rods and stuff I added some rods for printing in different lengths. Should print OK without supports. Did not include these in the TCP because it's trivial.

# Print Settings

Printer Brand: Prusa
Printer: i3 MK3
Rafts: No
Supports: No
Resolution: 0.2
Infill: 20%
Filament_brand: Any good quality PLA
Filament_color: Orange but doesn't matter
Filament_material: PLA

Notes: 
There are no supports required. 
I have made the design in a way that it is pretty easy to print.

G-Code for the Original Prusa i3 MK3 and for the Prusa i3 MK2(S) are included. 
It prints one piece of every design an 9 pieces of the clips. See fourth picture.
Printing time is around 11 hours and it takes around 110 grams of PLA.

I use 60°C bed temperature.
215 °C for the first layer and 210°C for all others.